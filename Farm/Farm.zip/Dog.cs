﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    public class Dog
    {
        public void Barking()
        {
            Console.WriteLine("barking...");
        }
    }
}
